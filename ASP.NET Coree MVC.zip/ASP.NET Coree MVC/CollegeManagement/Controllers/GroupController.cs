using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

[Authorize]
public sealed class GroupController(CollegeDbContext db) : Controller
{
    public IActionResult Index() => View(db.Groups);

    [Authorize(Roles = "Admin")]
    public IActionResult Create() => View();

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public IActionResult Create(string name, int course)
    {
        try
        {
            if (!db.AddGroup(new Group(name, course)))
            {
                ModelState.AddModelError(nameof(name), "Группа с таким названием уже существует.");
                return View();
            }

            TempData["Message"] = "Группа создана.";
            return RedirectToAction(nameof(Index));
        }
        catch (ArgumentException exception)
        {
            ModelState.AddModelError(string.Empty, exception.Message);
            return View();
        }
    }
}
