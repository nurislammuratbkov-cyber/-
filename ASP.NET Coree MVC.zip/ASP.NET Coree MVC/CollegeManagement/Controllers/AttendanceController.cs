using CollegeManagement.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

[Authorize]
public sealed class AttendanceController(AttendanceManager attendance, CollegeManagement.Data.CollegeDbContext db) : Controller
{
    public IActionResult Index()
    {
        ViewBag.Students = db.Students;
        ViewBag.Statistics = attendance.GetStatistics();
        return View(attendance.GetRecords());
    }

    [HttpPost]
    [Authorize(Roles = "Admin,Teacher")]
    [ValidateAntiForgeryToken]
    public IActionResult Set(Guid studentId, DateTime date, bool present)
    {
        var validDate = date == default ? DateOnly.FromDateTime(DateTime.Today) : DateOnly.FromDateTime(date);
        TempData["Message"] = attendance.SetAttendance(studentId, validDate, present)
            ? "Посещаемость сохранена."
            : "Студент не найден.";
        return RedirectToAction(nameof(Index));
    }
}
