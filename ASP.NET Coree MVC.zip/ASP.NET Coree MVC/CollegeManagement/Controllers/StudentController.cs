using CollegeManagement.Models;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

[Authorize]
public sealed class StudentController(StudentService students, CollegeManagement.Data.CollegeDbContext db) : Controller
{
    public IActionResult Index() => View(students.GetAll());

    [Authorize(Roles = "Admin")]
    public IActionResult Create()
    {
        ViewBag.Groups = db.Groups;
        return View();
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public IActionResult Create(string name, string surname, int age, string group)
    {
        try
        {
            var student = new Student(name, surname, age, group);
            if (!students.Add(student))
            {
                ModelState.AddModelError(nameof(group), "Выберите существующую группу.");
            }
            else
            {
                TempData["Message"] = "Студент добавлен.";
                return RedirectToAction(nameof(Index));
            }
        }
        catch (ArgumentException exception)
        {
            ModelState.AddModelError(string.Empty, exception.Message);
        }

        ViewBag.Groups = db.Groups;
        return View();
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public IActionResult Delete(Guid id)
    {
        TempData["Message"] = students.Remove(id) ? "Студент удалён." : "Студент не найден.";
        return RedirectToAction(nameof(Index));
    }
}
