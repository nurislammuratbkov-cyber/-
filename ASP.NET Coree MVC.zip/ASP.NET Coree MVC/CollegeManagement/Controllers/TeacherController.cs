using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

[Authorize]
public sealed class TeacherController(CollegeDbContext db) : Controller
{
    public IActionResult Index() => View(db.Teachers);

    [Authorize(Roles = "Admin")]
    public IActionResult Create() => View();

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public IActionResult Create(string name, string surname, int age, string subject, int experience)
    {
        try
        {
            db.AddTeacher(new Teacher(name, surname, age, subject, experience));
            TempData["Message"] = "Преподаватель добавлен.";
            return RedirectToAction(nameof(Index));
        }
        catch (ArgumentException exception)
        {
            ModelState.AddModelError(string.Empty, exception.Message);
            return View();
        }
    }
}
