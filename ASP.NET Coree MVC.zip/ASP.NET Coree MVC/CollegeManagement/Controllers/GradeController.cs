using CollegeManagement.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CollegeManagement.Controllers;

[Authorize]
public sealed class GradeController(CollegeDbContext db) : Controller
{
    public IActionResult Index() => View(db.Grades.OrderByDescending(grade => grade.Date).ToArray());

    [Authorize(Roles = "Admin,Teacher")]
    public IActionResult Create()
    {
        ViewBag.Students = db.Students;
        return View();
    }

    [HttpPost]
    [Authorize(Roles = "Admin,Teacher")]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Guid studentId, string subject, int value)
    {
        if (!db.AddGrade(studentId, subject, value))
        {
            ModelState.AddModelError(string.Empty, "Проверьте студента, предмет и оценку (допустимы значения от 2 до 5).");
            ViewBag.Students = db.Students;
            return View();
        }

        TempData["Message"] = "Оценка добавлена.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [Authorize(Roles = "Admin,Teacher")]
    [ValidateAntiForgeryToken]
    public IActionResult Delete(Guid id)
    {
        TempData["Message"] = db.RemoveGrade(id) ? "Оценка удалена." : "Оценка не найдена.";
        return RedirectToAction(nameof(Index));
    }
}
