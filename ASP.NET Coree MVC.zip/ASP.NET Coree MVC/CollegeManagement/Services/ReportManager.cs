using CollegeManagement.Data;

namespace CollegeManagement.Services;

public class ReportManager(CollegeDbContext db)
{
    protected internal string GenerateReport() =>
        $"Студентов: {db.Students.Count}; преподавателей: {db.Teachers.Count}; групп: {db.Groups.Count}; оценок: {db.Grades.Count}.";

    public string GenerateDashboardReport() => GenerateReport();
}
