using CollegeManagement.Models;
using Microsoft.AspNetCore.Identity;

namespace CollegeManagement.Services;

public sealed class UserAccountService
{
    private sealed record Credential(string Role, string PasswordHash);

    private readonly IReadOnlyDictionary<string, Credential> _credentials;
    private readonly PasswordHasher<UserAccount> _passwordHasher = new();

    public UserAccountService()
    {
        var users = new Dictionary<string, Credential>(StringComparer.OrdinalIgnoreCase);
        AddDemoAccount(users, "admin", "Admin");
        AddDemoAccount(users, "teacher", "Teacher");
        AddDemoAccount(users, "student", "Student");
        _credentials = users;
    }

    public UserAccount? Authenticate(string login, string password)
    {
        if (!_credentials.TryGetValue(login, out var credential))
        {
            return null;
        }

        var account = new UserAccount(login, credential.Role, new HashedPassword(credential.PasswordHash));
        return account.Login(password) ? account : null;
    }

    private void AddDemoAccount(IDictionary<string, Credential> users, string login, string role)
    {
        var account = new UserAccount(login, role, new HashedPassword(""));
        users.Add(login, new Credential(role, _passwordHasher.HashPassword(account, "College123!")));
    }
}
