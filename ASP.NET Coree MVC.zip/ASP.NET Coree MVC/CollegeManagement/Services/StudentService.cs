using CollegeManagement.Data;
using CollegeManagement.Models;

namespace CollegeManagement.Services;

public sealed class StudentService(CollegeDbContext db)
{
    public IReadOnlyList<Student> GetAll() => db.Students;
    public bool Add(Student student) => db.AddStudent(student);
    public bool Remove(Guid id) => db.RemoveStudent(id);
}
