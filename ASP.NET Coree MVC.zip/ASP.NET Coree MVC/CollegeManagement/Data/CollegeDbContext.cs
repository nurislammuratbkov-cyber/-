using CollegeManagement.Models;

namespace CollegeManagement.Data;

public sealed class CollegeDbContext
{
    private readonly List<Student> _students = [];
    private readonly List<Teacher> _teachers = [];
    private readonly List<Group> _groups = [];
    private readonly List<Subject> _subjects = [];
    private readonly GradeBook _gradeBook = new();

    public CollegeDbContext()
    {
        var firstGroup = new Group("ИС-21", 2);
        var secondGroup = new Group("ДИЗ-11", 1);
        var firstStudent = new Student("Алина", "Садыкова", 19, firstGroup.Name);
        var secondStudent = new Student("Тимур", "Иванов", 20, firstGroup.Name);
        var thirdStudent = new Student("Мария", "Петрова", 18, secondGroup.Name);
        firstGroup.AddStudent(firstStudent);
        firstGroup.AddStudent(secondStudent);
        secondGroup.AddStudent(thirdStudent);

        _students.AddRange([firstStudent, secondStudent, thirdStudent]);
        _groups.AddRange([firstGroup, secondGroup]);
        _teachers.AddRange([
            new Teacher("Елена", "Морозова", 42, "Математика", 18),
            new Teacher("Алексей", "Ким", 36, "Информатика", 12)
        ]);
        var mathematics = new Subject("Математика", 160);
        mathematics.AssignTeacher(_teachers[0]);
        var computerScience = new Subject("Информатика", 144);
        computerScience.AssignTeacher(_teachers[1]);
        _subjects.AddRange([mathematics, computerScience]);
        _gradeBook.Add(firstStudent, "Математика", 5);
        _gradeBook.Add(secondStudent, "Информатика", 4);
    }

    public IReadOnlyList<Student> Students => _students.AsReadOnly();
    public IReadOnlyList<Teacher> Teachers => _teachers.AsReadOnly();
    public IReadOnlyList<Group> Groups => _groups.AsReadOnly();
    public IReadOnlyList<Subject> Subjects => _subjects.AsReadOnly();
    public IReadOnlyList<Grade> Grades => _gradeBook.Grades;
    internal CollegeSettings Settings { get; } = new();

    public Student? FindStudent(Guid id) => _students.FirstOrDefault(student => student.StudentId == id);
    public bool AddStudent(Student student)
    {
        ArgumentNullException.ThrowIfNull(student);
        var group = _groups.FirstOrDefault(item => item.Name == student.Group);
        if (group is null || _students.Any(item => item.StudentId == student.StudentId))
        {
            return false;
        }

        group.AddStudent(student);
        _students.Add(student);
        return true;
    }

    public bool RemoveStudent(Guid id)
    {
        var student = FindStudent(id);
        if (student is null)
        {
            return false;
        }

        _groups.FirstOrDefault(group => group.Name == student.Group)?.RemoveStudent(id);
        _students.Remove(student);
        _gradeBook.RemoveForStudent(id);
        return true;
    }

    public void AddTeacher(Teacher teacher) => _teachers.Add(teacher);
    public bool AddGroup(Group group)
    {
        if (_groups.Any(existing => string.Equals(existing.Name, group.Name, StringComparison.OrdinalIgnoreCase)))
        {
            return false;
        }

        _groups.Add(group);
        return true;
    }

    public bool AddGrade(Guid studentId, string subject, int value)
    {
        var student = FindStudent(studentId);
        if (student is null)
        {
            return false;
        }

        return _gradeBook.Add(student, subject, value);
    }

    public bool RemoveGrade(Guid id) => _gradeBook.Remove(id);
}
