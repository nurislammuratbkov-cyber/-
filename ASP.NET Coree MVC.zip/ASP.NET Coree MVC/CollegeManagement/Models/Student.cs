namespace CollegeManagement.Models;

public sealed class Student : Person
{
    private readonly Guid _studentId;

    public Student(string name, string surname, int age, string group)
        : this(Guid.NewGuid(), name, surname, age, group)
    {
    }

    internal Student(Guid studentId, string name, string surname, int age, string group)
        : base(name, surname, age)
    {
        _studentId = studentId;
        Group = ValidateText(group, nameof(group));
        ValidateStudentData();
    }

    public Guid StudentId => _studentId;

    public string Group { get; private set; }

    public void SetAge(int age) => Age = age;

    internal void AssignGroup(string group) => Group = ValidateText(group, nameof(group));

    public string GetStudentInfo() => $"{DisplayBasicInfo()} · группа {Group}";

    private void ValidateStudentData()
    {
        _ = ValidateText(Name, nameof(Name));
        _ = ValidateText(Surname, nameof(Surname));
        _ = ValidateText(Group, nameof(Group));
        if (Age is < 15 or > 70)
        {
            throw new ArgumentOutOfRangeException(nameof(Age));
        }
    }
}
