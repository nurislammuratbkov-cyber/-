namespace CollegeManagement.Models;

public sealed class Group
{
    private readonly List<Student> _students = [];

    public Group(string name, int course)
    {
        Name = string.IsNullOrWhiteSpace(name) ? throw new ArgumentException("Укажите название группы.", nameof(name)) : name.Trim();
        if (course is < 1 or > 6)
        {
            throw new ArgumentOutOfRangeException(nameof(course), "Курс должен быть от 1 до 6.");
        }

        Course = course;
    }

    public string Name { get; }
    public int Course { get; }
    public IReadOnlyList<Student> Students => _students.AsReadOnly();

    public bool AddStudent(Student student)
    {
        ArgumentNullException.ThrowIfNull(student);
        if (_students.Any(existing => existing.StudentId == student.StudentId))
        {
            return false;
        }

        student.AssignGroup(Name);
        _students.Add(student);
        return true;
    }

    public bool RemoveStudent(Guid studentId)
    {
        var student = _students.FirstOrDefault(existing => existing.StudentId == studentId);
        if (student is null)
        {
            return false;
        }

        _students.Remove(student);
        return true;
    }
}
