using Microsoft.AspNetCore.Identity;

namespace CollegeManagement.Models;

internal sealed record HashedPassword(string Value);

public sealed class UserAccount
{
    private readonly string _login;
    private readonly string _passwordHash;
    private readonly string _role;
    private readonly PasswordHasher<UserAccount> _passwordHasher = new();

    public UserAccount(string login, string password, string role)
        : this(login, role, new HashedPassword(""))
    {
        _passwordHash = _passwordHasher.HashPassword(this, password);
    }

    internal UserAccount(string login, string role, HashedPassword passwordHash)
    {
        _login = string.IsNullOrWhiteSpace(login) ? throw new ArgumentException("Укажите логин.", nameof(login)) : login.Trim();
        _role = string.IsNullOrWhiteSpace(role) ? throw new ArgumentException("Укажите роль.", nameof(role)) : role.Trim();
        _passwordHash = passwordHash.Value;
    }

    public string LoginName => _login;
    public string Role => _role;
    public bool IsLoggedIn { get; private set; }

    public bool Login(string password)
    {
        if (string.IsNullOrEmpty(_passwordHash) ||
            _passwordHasher.VerifyHashedPassword(this, _passwordHash, password) == PasswordVerificationResult.Failed)
        {
            return false;
        }

        IsLoggedIn = true;
        return true;
    }

    public void Logout() => IsLoggedIn = false;

    public string GetSafeInfo() => $"{_login} ({_role})";
}
