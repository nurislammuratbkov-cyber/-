namespace CollegeManagement.Models;

public sealed class Teacher : Person
{
    private int _experience;

    public Teacher(string name, string surname, int age, string subject, int experience)
        : base(name, surname, age)
    {
        Subject = ValidateText(subject, nameof(subject));
        UpdateExperience(experience);
    }

    public string Subject { get; set; }

    public int Experience => _experience;

    public void UpdateExperience(int experience)
    {
        if (experience is < 0 or > 55)
        {
            throw new ArgumentOutOfRangeException(nameof(experience), "Стаж должен быть от 0 до 55 лет.");
        }

        _experience = experience;
    }

    public string GetTeacherInfo() => $"{DisplayBasicInfo()} · {Subject}, стаж {_experience} лет";
}
